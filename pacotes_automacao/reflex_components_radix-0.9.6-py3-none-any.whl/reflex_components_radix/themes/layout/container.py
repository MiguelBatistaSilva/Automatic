"""Declarative layout and common spacing props."""

from __future__ import annotations

from typing import Literal

from reflex_base.components.component import field
from reflex_base.style import STACK_CHILDREN_FULL_WIDTH
from reflex_base.vars.base import LiteralVar, Var
from reflex_components_core.core.breakpoints import Responsive
from reflex_components_core.el import elements

from reflex_components_radix.themes.base import RadixThemesComponent

LiteralContainerSize = Literal["1", "2", "3", "4"]


class Container(elements.Div, RadixThemesComponent):
    """Constrains the maximum width of page content."""

    tag = "Container"

    size: Var[Responsive[LiteralContainerSize]] = field(
        default=LiteralVar.create("3"),
        doc='The size of the container: "1" - "4" (default "3")',
    )

    @classmethod
    def create(
        cls,
        *children,
        padding: str = "16px",
        stack_children_full_width: bool = False,
        **props,
    ):
        """Create the container component.

        Args:
            *children: The children components.
            padding: The padding of the container.
            stack_children_full_width: If True, any vstack/hstack children will have 100% width.
            **props: The properties of the container.

        Returns:
            The container component.
        """
        if stack_children_full_width:
            props["style"] = {**STACK_CHILDREN_FULL_WIDTH, **props.pop("style", {})}
        return super().create(
            *children,
            padding=padding,
            **props,
        )


container = Container.create
